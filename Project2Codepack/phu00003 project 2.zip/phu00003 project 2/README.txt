Written by Andy Phu, phu00003

Compile and Run by:

Terminal:
    javac Game.java
    java Game

IntelliJ:
    Press the build button while viewing the Game.java file


Assumptions:
    Made using IntelliJ dark mode and Java 11, tested for IntelliJ light mode terminal

    JUnit tests are assumed to be tested with IntelliJ and JUnit 4

Outside Sources
-- idea to use StringBuilder to concatenate chars and strings: https://stackoverflow.com/questions/16282368/concatenate-chars-to-form-string-in-java

“I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”

Andy Phu